/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class Contado extends Pago implements Serializable{
    private TipoMoneda moneda;
    private final double DOLAR_COLON= 615;

    public Contado() {
    }
    
    public int conversionMontoADolares(){
        int montoDolar=((int)Math.round(super.getMontoPago()/DOLAR_COLON));
        super.setMontoPago(montoDolar);
        return montoDolar;
    }

    @Override
    public String toString() {
        StringBuilder hilera= new StringBuilder();
        String tipoMoneda;
        if (moneda.equals(TipoMoneda.COLON)) {
            hilera.append("₡");
            tipoMoneda= (super.getMontoPago()>1?" COLONES":" CÓLON");
        }else{
            hilera.append("$");
            tipoMoneda= (conversionMontoADolares()>1?" DÓLARES":" DÓLAR");
        }
        hilera.append(super.toString());
        hilera.append(tipoMoneda);
        return hilera.toString();
    }

    public void setMoneda(TipoMoneda moneda) {
        this.moneda = moneda;
    }
    
}
