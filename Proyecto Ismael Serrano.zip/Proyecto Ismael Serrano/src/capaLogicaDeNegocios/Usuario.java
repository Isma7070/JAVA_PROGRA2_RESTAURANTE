/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class Usuario implements Serializable{
    private String cedula;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String clave;
    private TipoUsuario tipoU;

    public Usuario(String cedula, String nombre,String apellido1, String apellido2, String clave, TipoUsuario tipoU) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido1= apellido1;
        this.apellido2 = apellido2;
        this.clave = clave;
        this.tipoU = tipoU;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public String getClave() {
        return clave;
    }

    public TipoUsuario getTipoU() {
        return tipoU;
    }

    
    
    
    @Override
    public String toString() {
        StringBuilder hilera= new StringBuilder();
        hilera.append(nombre).append(" ").append(apellido1).append(" ").append(apellido2);
        return hilera.toString();
    }
    

    
}
