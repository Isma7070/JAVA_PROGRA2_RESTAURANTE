/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class LineaDetalle implements Serializable{
    private Producto producto;
    private int cantidad;

    public LineaDetalle(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }
    public double precioLineaDetalle() {
       return producto.precioTotalProducto()*cantidad;
    }

    @Override
    public String toString() {
        String hilera="";
        if (producto instanceof PlatoPrincipal) {
            hilera+=((PlatoPrincipal)producto).getNombre()+"   "+cantidad+ ((((PlatoPrincipal)producto).getIndicaciones().equals(""))?"":"\n"+((PlatoPrincipal)producto).getIndicaciones()) +"\nPrecio: "+((PlatoPrincipal)producto).precioTotalProducto()*cantidad;
        }
        if (producto instanceof Refresco) {
            hilera+=((Refresco)producto).getNombre()+"   "+cantidad + "\nPrecio: "+((Refresco)producto).precioTotalProducto()*cantidad;
        }
        if (producto instanceof Adicional) {
            hilera+=((Adicional)producto).getNombre()+"   "+cantidad +"\nPrecio: "+((Adicional)producto).precioTotalProducto()*cantidad;
        }
        if (producto instanceof Combo) {
            hilera+="Combo"+"   "+cantidad+"\nPrecio: "+((Combo)producto).precioTotalProducto()*cantidad;
        }
        return hilera;
    }

    public Producto getProducto() {
        return producto;
    }
    
    
}
