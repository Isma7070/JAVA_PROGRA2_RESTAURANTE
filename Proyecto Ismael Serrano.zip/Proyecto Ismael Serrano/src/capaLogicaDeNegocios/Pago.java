/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;
import utilidades.NumerosLetras;

/**
 *
 * @author Home
 */
public class Pago implements Serializable{
    private double montoPago;
    

    public Pago() {
        
    }
    public String montoEnLetras(){
       return NumerosLetras.convertir((int)montoPago);
    }

    @Override
    public String toString() {
        return (int)montoPago+ "\n"+ montoEnLetras();
    }

    public void setMontoPago(double montoPago) {
        this.montoPago = montoPago;
    }

    public double getMontoPago() {
        return montoPago;
    }

    
   
    
    
}
