/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class Refresco extends Producto implements Serializable {

    private String nombre;
    private double precioBasico;
    private TamannoProducto tamanno;
    private TipoRefresco tipo;

    public Refresco(String codigo, String nombre, TipoRefresco tipo, TamannoProducto tamanio) {
        super(codigo);
        this.tipo = tipo;
        this.tamanno = tamanio;
        this.precioBasico = tipo.getPrecio();
        this.nombre = nombre;
    }

    @Override
    public double montoExtra() {
        //metodo monto extra por tamaño grande
        //gaseoso 350 extra, natural 200 extra
        if (tamanno.equals(TamannoProducto.Pequenno)) {
            return 0;
        } else {
            return tipo == TipoRefresco.Natural ? 200 : 350;
        }
    }

    @Override
    public double precioTotalProducto() {
        //precioBasico+montoExtraGrande
        return precioBasico+montoExtra();
    }

    @Override
    public String toString() {
        return nombre + "-" + tipo;
    }

    public TipoRefresco getTipo() {
        return tipo;
    }

    public double getPrecio() {
        return precioBasico;
    }

    public void setTipo(TipoRefresco tipo) {
        this.tipo = tipo;
    }

    @Override
    public String getCodigo() {
        return super.codigo;
    }

    @Override
    public void setCodigo(String codigo) {
        super.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTamanno(TamannoProducto tamanno) {
        this.tamanno = tamanno;
    }

}
