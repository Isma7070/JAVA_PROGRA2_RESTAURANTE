/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;



/**
 *
 * @author Home
 */
public class Credito extends Pago implements Serializable{
    private TipoTarjeta tipoTarjeta;
    private String numeroTarjeta;
    

    public Credito() {
    }
    public double descuento(){
        return (tipoTarjeta.equals(TipoTarjeta.VISA)?super.getMontoPago()*0.25:0);
    }
    public double montoFinal(){
        double monto=super.getMontoPago()-descuento();
        super.setMontoPago(monto);
        return monto;
    }

    @Override
    public String toString() {
        StringBuilder hilera = new StringBuilder();
        hilera.append("₡");
        hilera.append(super.toString());
        hilera.append((montoFinal() > 1 ? " COLONES" : " COLÓN"));
        return hilera.toString();
    }

    public void setTipoTarjeta(TipoTarjeta tipoTarjeta) {
        this.tipoTarjeta = tipoTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    public boolean validarTamannioNumeroTarjeta(){
        return numeroTarjeta.length()==16;
    }
    
    public boolean validarNumerosInicioVisa(){
        return numeroTarjeta.startsWith("4", 0);
    }
    
    public boolean validarNumerosInicioMasterCard(){
        int numero=Integer.parseInt(numeroTarjeta.substring(0, 2));
        System.out.println(numero);
        return numero>=51 && numero<=55;
    }
    
    public boolean validarTamannioCodigoSeguridad(String codigo){
        return codigo.length()==3;
    }
    
    public boolean validacionCompletaTarjeta(){
        int[] numeros= new int[numeroTarjeta.length()];
        int contDePorMedio=1;
        String divideDigitos;
        int sumaDigitos=0;
        for (int i = numeroTarjeta.length()-2; i >= 0; i--) {
            int numTemporal=Character.digit(numeroTarjeta.charAt(i), 10); 
            if (++contDePorMedio%2==0) {
                numeros[i]=numTemporal*2;
                divideDigitos=numeros[i]+"";
                if (divideDigitos.length()==2) {
                    numeros[i]= Character.digit(divideDigitos.charAt(0), 10)+Character.digit(divideDigitos.charAt(1), 10);
                }
            }else{
                numeros[i]=numTemporal;
            }
            sumaDigitos+=numeros[i];
        }
        sumaDigitos*=9;
        return Character.digit(numeroTarjeta.charAt(numeroTarjeta.length()-1), 10)==(int)(sumaDigitos%10);
        
    }

    public TipoTarjeta getTipoTarjeta() {
        return tipoTarjeta;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }
    
    
}
