/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class Adicional extends Producto implements Serializable{
    private String nombre;
    private double precioBasico;
    private TamannoProducto tamanno;
    private double precioAdicionalGrande;

    public Adicional(String codigo,String nombre, double precioBasico, TamannoProducto tamanno, double adicionalGrande) {
        super(codigo);
        this.precioBasico= precioBasico;
        this.tamanno=tamanno;
        this.precioAdicionalGrande= adicionalGrande;
        this.nombre=nombre;
    }
    
    @Override
    public double montoExtra(){
        return tamanno.equals(TamannoProducto.Grande)?precioAdicionalGrande:0;
    }
    
    @Override
    public double precioTotalProducto(){
        return montoExtra()+precioBasico;
    }

    public double getPrecio() {
        return precioBasico;
    }

    public TamannoProducto getTamanno() {
        return tamanno;
    }

    public void setPrecioBasico(double precioBasico) {
        this.precioBasico = precioBasico;
    }

    public void setPrecioAdicionalGrande(double precioAdicionalGrande) {
        this.precioAdicionalGrande = precioAdicionalGrande;
    }

    
  @Override
    public String getCodigo() {
        return super.codigo;
    }

    @Override
    public void setCodigo(String codigo) {
        super.codigo=codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }

    public void setTamanno(TamannoProducto tamanno) {
        this.tamanno = tamanno;
    }
    
    
    
}
