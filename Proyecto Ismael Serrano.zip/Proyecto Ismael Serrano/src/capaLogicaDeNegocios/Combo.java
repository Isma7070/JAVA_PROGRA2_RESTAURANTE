/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Home
 */
public class Combo extends Producto implements Serializable{
    private String nombre;
    private PlatoPrincipal platoP;
    private Refresco refresco;
    private ArrayList<Adicional> arrayAdicionales;
    private boolean agrandado;
    private boolean refill;

    public Combo(boolean agrandado, boolean refill) {
        super("001");
        this.agrandado = agrandado;
        this.refill= refill;
        arrayAdicionales= new ArrayList();
        this.nombre="Combo";
    }

    public boolean agregarAdicionales(Adicional unAdicional){
        boolean maximoAlcanzado=false;
        if (arrayAdicionales.size()<3) {
            arrayAdicionales.add(unAdicional);
        }else{
            maximoAlcanzado=true;
        }
        return maximoAlcanzado;
    }
   
    
    
    
    @Override
    public String toString() {
        return "Combo";
    }
    
    @Override
    public double montoExtra(){
        //tipo de refresco para extra refill, 200 Gaseoso, 100 natural
        if (refill) {
            return refresco.getTipo().equals(TipoRefresco.Natural)?100:200;
        }else{
            return 0;
        }
    }
    
    //suma de los productos en su precio basico
    public double precioSubTotal(){
        return precioAdicionales()+refresco.getTipo().getPrecio()+platoP.getPrecio();
    }
    
    //subtotal menos el 20% sin contar con el extra del refill y agrandado
    public double rebajo(){
        return precioSubTotal()*0.20;
    }
    
    //suma del precio de los adicionales en su precio basico
    public double precioAdicionales(){
        double precio=0;
        for (Adicional arrayAdicionale : arrayAdicionales) {
            precio+=arrayAdicionale.getPrecio();
        }
        return precio;
    }
    
    //suma del monto extra por refill según el tipo de refresco más el extra del agrandado
    public double precioExtra(){
        return montoExtra()+(agrandado?300:0);
    }
    
    //suma de los productos menos el 20% y se le añade el monto extra del refill y agrandado.
    @Override
    public double precioTotalProducto(){
        return precioSubTotal()-rebajo()+precioExtra();
    }


    public void setPlatoP(PlatoPrincipal platoP) {
        this.platoP = platoP;
    }

    public void setRefresco(Refresco refresco) {
        this.refresco = refresco;
    }

    public void setArrayAdicionales(ArrayList<Adicional> arrayAdicionales) {
        this.arrayAdicionales = arrayAdicionales;
    }


    @Override
    public double getPrecio() {
        return precioTotalProducto();
    }

    @Override
    public String getCodigo() {
        return super.codigo;
    }

    @Override
    public void setCodigo(String codigo) {
       super.codigo=codigo;
    }

    @Override
    public String getNombre() {
        return "Combo";
    }
    
    
    
}
