/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import capaAccesoADatos.ProductoBD;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Home
 */
public abstract class Producto implements Serializable {
    protected String codigo;

    public Producto(String codigo) {
        this.codigo = codigo;

    }

    //double montoExtra()
    public abstract double montoExtra();
    // double precioTotalProducto()
    public abstract double precioTotalProducto();
 
    public abstract double getPrecio();
    
    public abstract String getCodigo();
    
    public abstract void setCodigo(String codigo);
    
    public abstract String getNombre();

    @Override
    public abstract String toString();
    
    
    
    
    
    public static Producto consultarProducto(String codigo) throws Exception{
        return ProductoBD.getInstance().consultarDepartamento(codigo);
    }
    public static void agregarProducto(Producto producto) throws Exception{
        ProductoBD.getInstance().agregarDepartamento(producto);
    }
    public static void eliminarProducto(String codigo) throws Exception{
      ProductoBD.getInstance().eliminarDepartamento(codigo);
    }
    public static void modificarProducto(Producto producto)throws Exception{
        ProductoBD.getInstance().modificarDepartamento(producto);
    }
    public static ArrayList<Producto> listadoProducto() throws Exception {
       return ProductoBD.getInstance().listaProductos();
    }
}
