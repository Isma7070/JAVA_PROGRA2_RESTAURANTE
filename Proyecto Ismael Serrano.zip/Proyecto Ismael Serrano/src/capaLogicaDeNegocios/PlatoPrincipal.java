/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import java.io.Serializable;

/**
 *
 * @author Home
 */
public class PlatoPrincipal extends Producto implements Serializable{
    private double precioBasico;
    private String nombre;
    private String indicaciones;
    

    public PlatoPrincipal(String codigo,String nombre, double precioBasico, String indicaciones) {
        super(codigo);
        this.precioBasico= precioBasico;
        this.nombre=nombre;
        this.indicaciones=indicaciones;
    }
    
    @Override
    public double montoExtra(){
        //si el plato tiene en su nombre la palabra "doble" se le cobra un 10% extra del valor
        return nombre.contains("doble")?precioBasico*0.10:0;
    }
    
    @Override
    public double precioTotalProducto(){
        //extra + precioBasico
        return montoExtra()+precioBasico;
    }

    @Override
    public double getPrecio() {
        return precioBasico;
    }

    public void setPrecioBasico(double precioBasico) {
        this.precioBasico = precioBasico;
    }

    public void setIndicaciones(String indicaciones) {
        this.indicaciones = indicaciones;
    }
 
    
    @Override
    public String getCodigo() {
        return super.codigo;
    }

    @Override
    public void setCodigo(String codigo) {
        super.codigo=codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }

    public double getPrecioBasico() {
        return precioBasico;
    }

    public String getIndicaciones() {
        return indicaciones;
    }
    
    
    
   
}
