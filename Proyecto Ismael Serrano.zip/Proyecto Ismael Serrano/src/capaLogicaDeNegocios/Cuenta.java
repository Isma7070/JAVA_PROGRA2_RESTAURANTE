/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaLogicaDeNegocios;

import capaAccesoADatos.CuentaBD;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Home
 */
public class Cuenta implements Serializable{
    public static int contCuentas=1;
    private int numeroCuenta;
    private Date fecha;
    private int numeroMesa;
    private ArrayList<LineaDetalle> arrayDetalles;
    private Pago montoPago;
    private final double IV= 0.13;
    private final double IMPUESTO_SERVICIO=0.10;
    private Usuario salonero;
    
    

    public Cuenta() {
        this.arrayDetalles= new ArrayList();
        this.fecha= new Date();
        this.numeroCuenta= contCuentas;
        ++contCuentas;
    }

    public boolean agregarDetalle(LineaDetalle detalle){
        return arrayDetalles.add(detalle);
    }
    
    public double sumaMontoDetallesSinImpuestos(){
        double monto=0;
        for (LineaDetalle arrayDetalle : arrayDetalles) {
            monto+=arrayDetalle.precioLineaDetalle();
        }
        return monto;
    }
    public double montoImpuestosIV(){
        return sumaMontoDetallesSinImpuestos()*IV;
    }
    
    public double montoImpuestosServicio(){
        return sumaMontoDetallesSinImpuestos()*IMPUESTO_SERVICIO;
    }
    
    public double total(){
        return sumaMontoDetallesSinImpuestos()+montoImpuestosIV()+montoImpuestosServicio();
    }
    
    public void establecerPago(boolean contado, boolean credito){
        if (contado) {
            montoPago=new Contado();
        }
        if (credito) {
            montoPago= new Credito();
        }
        montoPago.setMontoPago(total());
    }
    
    
    
    @Override
    public String toString() {
        StringBuilder hilera= new StringBuilder();
        SimpleDateFormat formatoHora= new SimpleDateFormat("'Hora: 'hh:mm");
        SimpleDateFormat formatoFecha= new SimpleDateFormat("'Fecha: 'dd/MM/yy");
        
        hilera.append("Cuenta #").append(numeroCuenta).append("\n").append("Mesa ").append(numeroMesa)
                .append("\n").append(formatoFecha.format(fecha)).append("\n").append(formatoHora.format(fecha))
                .append("\n").append("Atiende: ").append(salonero.toString()).append("\n");
        for (LineaDetalle arrayDetalle : arrayDetalles) {
            hilera.append("----------------------------\n").append(arrayDetalle.toString()).append("\n");
        }
        hilera.append("________________________________________");
        return hilera.toString();
    }
    

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public ArrayList<LineaDetalle> getArrayDetalles() {
        return arrayDetalles;
    }

    public Pago getTipoPago() {
        return montoPago;
    }

    public Usuario getSalonero() {
        return salonero;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    

    public void setSalonero(Usuario salonero) {
        this.salonero = salonero;
    }

    public void setArrayDetalles(ArrayList<LineaDetalle> arrayDetalles) {
        this.arrayDetalles = arrayDetalles;
    }

    public void setMontoPago(Pago montoPago) {
        this.montoPago = montoPago;
    }

    public static void setContCuentas(int contCuentas) {
        Cuenta.contCuentas = contCuentas;
    }
    
    
    
    
   public static Cuenta consultarCuenta(int numero) throws Exception{
        return CuentaBD.getInstance().consultarCuenta(numero);
    }
    public static void agregarCuenta(Cuenta cuenta )throws Exception{
        CuentaBD.getInstance().agregarCuenta(cuenta);
    }
    public static void eliminarCuenta(int numero) throws Exception{
      CuentaBD.getInstance().eliminarCuenta(numero);
    }
    public static void modifciarCuenta(Cuenta cuenta)throws Exception{
        CuentaBD.getInstance().modificarCuenta(cuenta);
    }
    public static ArrayList<Cuenta> listadoCuentas() throws Exception {
       return CuentaBD.getInstance().listaCuentas();
    }
}
