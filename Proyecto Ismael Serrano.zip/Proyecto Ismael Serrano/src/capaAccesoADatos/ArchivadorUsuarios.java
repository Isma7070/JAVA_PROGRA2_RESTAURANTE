/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaAccesoADatos;

import capaLogicaDeNegocios.TipoUsuario;
import capaLogicaDeNegocios.Usuario;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 *
 * @author Home
 */
public class ArchivadorUsuarios {
    
    private static ArrayList<Usuario>arrayUsuarios = new ArrayList();    
    //metodo que inicia la lista de Usuarios preestablecidos
    public static void iniciarUsuarios(){
        arrayUsuarios.add(new Usuario("117350921", "Ismael","Serrano","Soto","123isma", TipoUsuario.Administrador));
        arrayUsuarios.add(new Usuario("123456789", "Ana","Odio","Ugalde","admin", TipoUsuario.Administrador));
        arrayUsuarios.add(new Usuario("987654321", "Keitling","Pérez","Zuñiga","123kei", TipoUsuario.Salonero));
        arrayUsuarios.add(new Usuario("1122334455", "Juan","Serrano","Soto","juan789", TipoUsuario.Salonero));
        arrayUsuarios.add(new Usuario("2233445566", "Melba","Soto","Martinez","melba123", TipoUsuario.Salonero));
        arrayUsuarios.add(new Usuario("3344556677", "Mónica","Serrano","Soto","moni456", TipoUsuario.Salonero));
        
    }
    //devuelve la lista deUsuarios
    public static String listaUsuarios(){
        String hilera="";
        Iterator iter = arrayUsuarios.iterator();
        while(iter.hasNext()){
            hilera+=iter.next();
        }
        return hilera;
    }
    
     public static ArrayList<Usuario> getArrayUsuarios() {
        return arrayUsuarios;
    }
    
    //método que verifica que la clave ingresada por el usuario sea la correcta y devuelve el usuario elegido
    public static Usuario comprobarCedula(String id){
        Usuario usuarioCorrecto=null;
        for (Usuario arrayUsuario : arrayUsuarios) {
            if (arrayUsuario.getCedula().equalsIgnoreCase(id)) {
                usuarioCorrecto= arrayUsuario;
            }
        }
        return usuarioCorrecto;
    }
}

